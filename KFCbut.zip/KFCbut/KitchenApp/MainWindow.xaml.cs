﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KitchenApp
{
    class StackOrder
    {
        public StackPanel stack;
        public Database.Order order;
    }
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        private void timerTick(object sender, EventArgs e)
        {
            Build();
        }

        Database.DBEntities Connection = new Database.DBEntities();
        public MainWindow()
        {
            InitializeComponent();
            Build();
            System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
            timer.Tick += new EventHandler(timerTick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();
            //with few respect, please 🙏🏻🙏🏻🙏🏻 
        }
        public void Build()
        {
            KitchenPanel.Children.Clear();
            List<Database.Order> Order = Connection.Order.Where(o => o.Status == "В очереди" || o.Status == "Готовится").OrderBy(m => m.NumberOrder).ToList();
            foreach (var order in Order)
            {
                StackPanel stack1 = new StackPanel();
                stack1.Height = 150;
                stack1.Width = 550;
                stack1.Orientation = Orientation.Horizontal;
                stack1.Margin = new Thickness(0, 20, 0, 0);
                stack1.HorizontalAlignment = HorizontalAlignment.Center;
                stack1.VerticalAlignment = VerticalAlignment.Top;
                if (order.Status != "Готовится")
                { stack1.Background = new SolidColorBrush(Colors.Lavender); }
                else { stack1.Background = new SolidColorBrush(Colors.PaleVioletRed); }
                KitchenPanel.Children.Add(stack1);

                StackPanel stack2 = new StackPanel();
                stack2.Width = 365;
                stack2.Margin = new Thickness(10, 10, 15, 10);
                stack1.Children.Add(stack2);

                TextBlock NumOrder = new TextBlock();
                NumOrder.Text = order.NumberOrder.ToString();
                NumOrder.FontFamily = new FontFamily("Franklin Gothic Demi");
                NumOrder.FontSize = 22;
                stack2.Children.Add(NumOrder);
                int a = 0;
                TextBlock ComOrder = new TextBlock();
                List<Database.OrderCompound> CompOrder = Connection.OrderCompound.OrderBy(m => m.OrderNumber).ToList();
                foreach (var dish in CompOrder)
                {
                    if (dish.OrderNumber == order.NumberOrder)
                    {
                        ComOrder.Text += dish.Dish + " " + dish.Count + " шт.\n";
                        a++;
                    }
                }
                ComOrder.TextWrapping = TextWrapping.Wrap;
                ComOrder.Margin = new Thickness(0, 10, 0, 0);
                ComOrder.FontFamily = new FontFamily("Franklin Gothic Demi");
                ComOrder.FontSize = 16;
                stack2.Children.Add(ComOrder);
                for (int b = 5; b <= a; b++)
                { stack1.Height += 12; }

                StackPanel stack3 = new StackPanel();
                stack1.Children.Add(stack3);

                Button TakeOrder = new Button();
                TakeOrder.Width = 150;
                TakeOrder.Height = 50;
                if (order.Status!="Готовится")
                { TakeOrder.Content = "🔔"; }
                else { TakeOrder.Content = "🛎️"; }
                TakeOrder.Margin= new Thickness(0, 48, 0, 0);
                TakeOrder.Click += TakeOrder_Click;
                TakeOrder.DataContext = new StackOrder()
                {
                    order = order,
                    stack = stack1,
                };
                TakeOrder.FontFamily = new FontFamily("Franklin Gothic Demi");
                TakeOrder.FontSize = 18;
                stack3.Children.Add(TakeOrder);
            }
        }

        private void TakeOrder_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null)
            {
                StackOrder stackOrder = button.DataContext as StackOrder;
                if (stackOrder != null)
                {
                    
                    button.Click -= TakeOrder_Click;
                    stackOrder.order.Status = "Готовится";
                    button.Click += GiveAnOrder_Click;
                    Connection.SaveChanges();
                }
            }
        }
        private void GiveAnOrder_Click(object sender, RoutedEventArgs e) 
        {
            var button = sender as Button;
           
            if (button != null)
            {
                StackOrder stackOrder = button.DataContext as StackOrder;
                if (stackOrder != null)
                {
                    stackOrder.order.Status = "Готово к отдаче";
                    Connection.SaveChanges();
                    
                    Build();
                }
            }
        }
    }
}
