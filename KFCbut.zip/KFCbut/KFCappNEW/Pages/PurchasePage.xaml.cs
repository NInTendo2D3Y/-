﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFCappNEW.Pages
{
    /// <summary>
    /// Логика взаимодействия для PurchasePage.xaml
    /// </summary>
    public partial class PurchasePage : Page
    {
        Database.DBEntities Connection = new Database.DBEntities();
        public PurchasePage()
        {
            InitializeComponent();
            Build();
        }

        public struct BuscketInfo
        {
            public bool IsSet;
            public int Count;
        }

        public static Dictionary<string, BuscketInfo> Buscket = new Dictionary<string, BuscketInfo>();


        public void Build()
        {

            Stack.Children.Clear();
            Fullprice.HorizontalAlignment = HorizontalAlignment.Center;
            Fullprice.TextWrapping = TextWrapping.Wrap;
            Fullprice.Margin = new Thickness(0, 800, 0, 0);
            Fullprice.VerticalAlignment = VerticalAlignment.Top;
            Fullprice.FontFamily = new FontFamily("Bahnschrift Light");
            Fullprice.TextAlignment = TextAlignment.Center;
            Fullprice.FontSize = 22;
            double fullprice = 0;


            foreach (var val in Buscket)
            {
                StackPanel BusckList = new StackPanel();
                BusckList.VerticalAlignment = VerticalAlignment.Center;
                BusckList.Height = 200;
                BusckList.Width = 800;
                BusckList.Orientation = Orientation.Horizontal;
                BusckList.Background = new SolidColorBrush(Colors.Lavender);
                BusckList.Margin = new Thickness(0, 0, 0, 20);
                Stack.Children.Add(BusckList);

                StackPanel NameAndNum = new StackPanel();
                NameAndNum.Orientation = Orientation.Vertical;
                NameAndNum.HorizontalAlignment = HorizontalAlignment.Center;
                NameAndNum.Margin = new Thickness(35, 20, 0, 10);
                BusckList.Children.Add(NameAndNum);

                TextBlock Name = new TextBlock();
                if (val.Value.IsSet)
                { Name.Text = "Сет " + val.Key; }
                else { Name.Text = val.Key; }
                Name.Width = 500;
                Name.Height = 50;
                Name.TextWrapping = TextWrapping.Wrap;
                Name.FontFamily = new FontFamily("Bahnschrift Light");
                Name.FontSize = 22;
                NameAndNum.Children.Add(Name);

                StackPanel CountStack = new StackPanel();
                CountStack.Orientation = Orientation.Horizontal;
                NameAndNum.Children.Add(CountStack);

                Label Count = new Label();
                Count.Content = "Количество";
                Count.Width = 150;
                Count.Height = 60;
                Count.FontSize = 22;
                Count.FontFamily = new FontFamily("Bahnschrift Light");
                Count.Margin = new Thickness(0, 20, -10, 0);
                CountStack.Children.Add(Count);

                Button CountDown = new Button();
                CountDown.Content = "✖️";
                CountDown.FontFamily = new FontFamily("Bahnschrift Light");
                CountDown.FontSize = 10;
                CountDown.Width = 20;
                CountDown.Height = 20;
                CountDown.DataContext = val.Key;
                CountDown.Click += CountDown_Click;
                CountStack.Children.Add(CountDown);

                TextBlock CountNum = new TextBlock();
                CountNum.Width = 50;
                CountNum.Height = 50;
                CountNum.FontFamily = new FontFamily("Bahnschrift Light");
                CountNum.FontSize = 22;
                CountNum.Margin = new Thickness(25, 20, -10, 0);
                CountNum.Text = val.Value.Count.ToString();
                CountStack.Children.Add(CountNum);

                Button CountUp = new Button();
                CountUp.Content = "✔️";
                CountUp.FontFamily = new FontFamily("Bahnschrift Light");
                CountUp.FontSize = 10;
                CountUp.Width = 20;
                CountUp.Height = 20;
                CountUp.DataContext = val.Key;
                CountUp.Click += CountUp_Click;
                CountStack.Children.Add(CountUp);

                StackPanel PriceAndDel = new StackPanel();
                PriceAndDel.Orientation = Orientation.Vertical;
                PriceAndDel.HorizontalAlignment = HorizontalAlignment.Center;
                PriceAndDel.Margin = new Thickness(0, 20, 0, 10);
                BusckList.Children.Add(PriceAndDel);

                TextBlock Price = new TextBlock();
                Price.Width = 100;
                Price.Height = 50;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Bahnschrift Light");
                Price.FontSize = 22;
                List<Database.Dish> dishList = Connection.Dish.ToList();

                decimal price = 0;
                if (val.Value.IsSet == false)
                {
                    foreach (var dish in dishList)
                    {
                        if (dish.Name == val.Key)
                        {
                            Price.Text = Math.Round((dish.Cost * val.Value.Count), 2).ToString();
                            fullprice += Convert.ToDouble(Price.Text);
                            break;
                        }

                    }
                }
                else
                {
                    List<Database.DishSet> setList = Connection.DishSet.ToList();

                    foreach (var set in setList)
                    {
                        if (set.Name == val.Key)
                        {
                            foreach (var dish in dishList)
                            {
                                if (set.Dish == dish.Name)
                                { price += dish.Cost; }
                            }

                        }
                    }
                    price = price * Convert.ToDecimal(1.1) * val.Value.Count;
                    Price.Text = Convert.ToString(Math.Round(price, 2)) + " руб.";
                    fullprice += Convert.ToDouble(price);
                }


                PriceAndDel.Children.Add(Price);
                Fullprice.Text = "Всего к оплате: " + fullprice + " руб.";

                Button del = new Button();
                del.Width = 50;
                del.Height = 50;
                del.FontFamily = new FontFamily("Bahnschrift Light");
                del.FontSize = 30;
                del.Margin = new Thickness(0, 16, 0, 0);
                del.Content = "❌";
                del.Click += Del_Click;
                del.DataContext = val.Key;
                PriceAndDel.Children.Add(del);
            }


        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string key = button.DataContext as string;
            Windows.AreYouSureWindow window = new Windows.AreYouSureWindow();
            if (button != null)
            {
                if (window.ShowDialog() == true)
                {
                    if (key != null)
                    {
                        if (Buscket.ContainsKey(key))
                        {
                            Buscket.Remove(key);
                            Stack.Children.Clear();
                            Build();
                        }
                    }
                }
            }
        }

        private void CountDown_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                string key = button.DataContext as string;
                if (key != null)
                {
                    if (Buscket.ContainsKey(key))
                    {
                        var buscket = Buscket[key];
                        if (buscket.Count > 1)
                        {
                            buscket.Count--;
                            Buscket[key] = buscket;
                            Stack.Children.Clear();
                            Build();
                        }
                    }
                }
            }
        }

        private void CountUp_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                string key = button.DataContext as string;
                if (key != null)
                {
                    if (Buscket.ContainsKey(key))
                    {
                        var buscket = Buscket[key];
                        buscket.Count++;
                        Buscket[key] = buscket;
                        Stack.Children.Clear();
                        Build();
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(MainWindow.Menu);

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Windows.AreYouSureWindow window = new Windows.AreYouSureWindow();
            window.Title = "Оплата";
            window.Text.Text = "Оформить заказ?";
            window.Text.Height = 65;
            if (window.ShowDialog() == true)
            {
                Database.Order newOrder = new Database.Order();


                int number;
                var lastOrder = Connection.Order.OrderBy(o => o.NumberOrder).ToList().LastOrDefault();
                if (lastOrder == null)
                {
                    number = 1;
                }
                else
                {
                    number = lastOrder.NumberOrder + 1;
                }
                string status = "В очереди";

                newOrder.NumberOrder = number;
                newOrder.Status = status;
                Connection.Order.Add(newOrder);

                Dictionary<Database.Dish, int> keyValuePairs = new Dictionary<Database.Dish, int>();

                foreach (var buscket in Buscket)
                {
                    if (buscket.Value.IsSet == true)
                    {
                        var list = Connection.DishSet.Where(ds => ds.Name == buscket.Key).ToList();
                        foreach (var item in list)
                        {
                            Console.WriteLine(item.Dish1);
                            if (keyValuePairs.ContainsKey(item.Dish1))
                            {
                                keyValuePairs[item.Dish1] += buscket.Value.Count * item.Count;
                            }
                            else
                            {
                                keyValuePairs.Add(item.Dish1, buscket.Value.Count * item.Count);
                            }
                        }
                    }
                    else
                    {
                        var list = Connection.Dish.Where(ds => ds.Name == buscket.Key).ToList();
                        foreach (var item in list)
                        {
                            Console.WriteLine(item);
                            if (keyValuePairs.ContainsKey(item))
                            {
                                keyValuePairs[item] += buscket.Value.Count;
                            }
                            else
                            {
                                keyValuePairs.Add(item, buscket.Value.Count);
                            }
                        }
                    }
                }

                foreach (var buscket in keyValuePairs)
                {

                    Database.OrderCompound newCompound = new Database.OrderCompound();
                    newCompound.OrderNumber = number;
                    newCompound.Dish = buscket.Key.Name;
                    newCompound.Count = buscket.Value;

                   Connection.OrderCompound.Add(newCompound);
                }                
                Connection.SaveChanges();
                Stack.Children.Clear();
                Buscket.Clear();
                NavigationService.Navigate(MainWindow.Menu);
            }
        }
    }
}
