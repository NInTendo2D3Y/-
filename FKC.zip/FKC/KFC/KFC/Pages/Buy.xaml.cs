﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC.Pages
{

    public partial class Buy : Page
    {
        public static MainWindow MainMenu;
        Database.DBEntities Connection = new Database.DBEntities();
        public Buy()
        {
            InitializeComponent();
            Build();
            MainMenu = new MainWindow();
        }

        public struct BuyMenuInfo
        {
            public bool Seti4ek;
            public int Count;
        }

        public static Dictionary<string, BuyMenuInfo> BuyMenu = new Dictionary<string, BuyMenuInfo>();


        public void Build()
        {

            StackPanel.Children.Clear();
            Fullprice.HorizontalAlignment = HorizontalAlignment.Center;
            Fullprice.TextWrapping = TextWrapping.Wrap;
            Fullprice.Margin = new Thickness(0, 800, 0, 0);
            Fullprice.VerticalAlignment = VerticalAlignment.Top;
            Fullprice.FontFamily = new FontFamily("c");
            Fullprice.TextAlignment = TextAlignment.Center;
            Fullprice.FontSize = 22;
            double fullprice = 0;


            foreach (var valoume in BuyMenu)
            {
                StackPanel BuyMenuList = new StackPanel();
                BuyMenuList.VerticalAlignment = VerticalAlignment.Center;
                BuyMenuList.Height = 200;
                BuyMenuList.Width = 800;
                BuyMenuList.Orientation = Orientation.Horizontal;
                BuyMenuList.Background = new SolidColorBrush(Colors.PeachPuff);
                BuyMenuList.Margin = new Thickness(0, 0, 0, 20);
                StackPanel.Children.Add(BuyMenuList);

                StackPanel NumberName = new StackPanel();
                NumberName.Orientation = Orientation.Vertical;
                NumberName.HorizontalAlignment = HorizontalAlignment.Center;
                NumberName.Margin = new Thickness(35, 20, 0, 10);
                BuyMenuList.Children.Add(NumberName);

                TextBlock Name = new TextBlock();
                if (valoume.Value.Seti4ek)
                { Name.Text = "Сет " + valoume.Key; }
                else { Name.Text = valoume.Key; }
                Name.Width = 500;
                Name.Height = 50;
                Name.TextWrapping = TextWrapping.Wrap;
                Name.FontFamily = new FontFamily("Bahnschrift Light");
                Name.FontSize = 22;
                NumberName.Children.Add(Name);

                StackPanel Count = new StackPanel();
                Count.Orientation = Orientation.Horizontal;
                NumberName.Children.Add(Count);

                Label Counts = new Label();
                Counts.Content = "Количество";
                Counts.Width = 150;
                Counts.Height = 60;
                Counts.FontSize = 22;
                Counts.FontFamily = new FontFamily("Bahnschrift Light");
                Counts.Margin = new Thickness(0, 20, -10, 0);
                Count.Children.Add(Counts);

                Button PutAway = new Button();
                PutAway.Content = "➖";
                PutAway.FontFamily = new FontFamily("Bahnschrift Light");
                PutAway.FontSize = 26;
                PutAway.Width = 50;
                PutAway.Height = 50;
                PutAway.DataContext = valoume.Key;
                PutAway.Click += CountDown_Click;
                Count.Children.Add(PutAway);

                TextBlock CountNumer = new TextBlock();
                CountNumer.Width = 50;
                CountNumer.Height = 50;
                CountNumer.FontFamily = new FontFamily("Bahnschrift Light");
                CountNumer.FontSize = 22;
                CountNumer.Margin = new Thickness(25, 20, -10, 0);
                CountNumer.Text = valoume.Value.Count.ToString();
                Count.Children.Add(CountNumer);

                Button Add = new Button();
                Add.Content = "+";
                Add.FontFamily = new FontFamily("Bahnschrift Light");
                Add.FontSize = 40;
                Add.Width = 50;
                Add.Height = 50;
                Add.DataContext = valoume.Key;
                Add.Click += CountUp_Click;
                Count.Children.Add(Add);

                StackPanel PriceDelete = new StackPanel();
                PriceDelete.Orientation = Orientation.Vertical;
                PriceDelete.HorizontalAlignment = HorizontalAlignment.Center;
                PriceDelete.Margin = new Thickness(0, 20, 0, 10);
                BuyMenuList.Children.Add(PriceDelete);

                TextBlock Price = new TextBlock();
                Price.Width = 100;
                Price.Height = 50;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Bahnschrift Light");
                Price.FontSize = 22;
                List<Database.Course> dishList = Connection.Courses.ToList();

                decimal price = 0;
                if (valoume.Value.Seti4ek == false)
                {
                    foreach (var course in dishList)
                    {
                        if (course.NameCourse == valoume.Key)
                        {
                            Price.Text = Math.Round((course.Cost * valoume.Value.Count), 2).ToString();
                            fullprice += Convert.ToDouble(Price.Text);
                            break;
                        }

                    }
                }
                else
                {
                    List<Database.CourseSet> setList = Connection.CourseSets.ToList();

                    foreach (var foodset in setList)
                    {
                        if (foodset.NameSet == valoume.Key)
                        {
                            foreach (var course in dishList)
                            {
                                if (foodset.Course1.NameCourse == course.NameCourse)
                                { price += course.Cost; }
                            }

                        }
                    }
                    price = price * Convert.ToDecimal(1.1) * valoume.Value.Count;
                    Price.Text = Convert.ToString(Math.Round(price, 2)) + " руб.";
                    fullprice += Convert.ToDouble(price);
                }


                PriceDelete.Children.Add(Price);
                Fullprice.Text = "Всего к оплате: " + fullprice + " руб.";

                Button delete = new Button();
                delete.Width = 200;
                delete.Height = 50;
                delete.FontFamily = new FontFamily("Bahnschrift Light");
                delete.FontSize = 22;
                delete.Margin = new Thickness(0, 16, 0, 0);
                delete.Content = "Удалить блюдо";
                delete.Click += Del_Click;
                delete.DataContext = valoume.Key;
                PriceDelete.Children.Add(delete);
            }


        }

        private void Del_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string key = button.DataContext as string;
            Pages.ActionConfirmation window = new Pages.ActionConfirmation();
            if (button != null)
            {
                if (window.ShowDialog() == true)
                {
                    if (key != null)
                    {
                        if (BuyMenu.ContainsKey(key))
                        {
                            BuyMenu.Remove(key);
                            StackPanel.Children.Clear();
                            Build();
                        }
                    }
                }
            }
        }

        private void CountDown_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                string key = button.DataContext as string;
                if (key != null)
                {
                    if (BuyMenu.ContainsKey(key))
                    {
                        var buscket = BuyMenu[key];
                        if (buscket.Count > 1)
                        {
                            buscket.Count--;
                            BuyMenu[key] = buscket;
                            StackPanel.Children.Clear();
                            Build();
                        }
                    }
                }
            }
        }

        private void CountUp_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                string key = button.DataContext as string;
                if (key != null)
                {
                    if (BuyMenu.ContainsKey(key))
                    {
                        var buscket = BuyMenu[key];
                        buscket.Count++;
                        BuyMenu[key] = buscket;
                        StackPanel.Children.Clear();
                        Build();
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(MainMenu);

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Pages.ActionConfirmation window = new Pages.ActionConfirmation();
            window.Title = "Оплата";
            window.Text.Text = "Оформить заказ?";
            window.Text.Height = 65;
            if (window.ShowDialog() == true)
            {
                Database.Order newOrder = new Database.Order();


                int number;
                var lastOrder = Connection.Orders.OrderBy(o => o.OrderNumber).ToList().LastOrDefault();
                if (lastOrder == null)
                {
                    number = 1;
                }
                else
                {
                    number = lastOrder.OrderNumber + 1;
                }
                string status = "В очереди";

                newOrder.OrderNumber = number;
                newOrder.Status = status;
                Connection.Orders.Add(newOrder);

                Dictionary<Database.Course, int> keyValuePairs = new Dictionary<Database.Course, int>();

                foreach (var buscket in BuyMenu)
                {
                    if (buscket.Value.Seti4ek == true)
                    {
                        var list = Connection.CourseSets.Where(ds => ds.NameSet == buscket.Key).ToList();
                        foreach (var item in list)
                        {
                            Console.WriteLine(item.Course1);
                            if (keyValuePairs.ContainsKey(item.Course1))
                            {
                                keyValuePairs[item.Course1] += buscket.Value.Count * item.Count;
                            }
                            else
                            {
                                keyValuePairs.Add(item.Course1, buscket.Value.Count * item.Count);
                            }
                        }
                    }
                    else
                    {
                        var list = Connection.Courses.Where(ds => ds.NameCourse == buscket.Key).ToList();
                        foreach (var item in list)
                        {
                            Console.WriteLine(item);
                            if (keyValuePairs.ContainsKey(item))
                            {
                                keyValuePairs[item] += buscket.Value.Count;
                            }
                            else
                            {
                                keyValuePairs.Add(item, buscket.Value.Count);
                            }
                        }
                    }
                }

                foreach (var buscket in keyValuePairs)
                {

                    Database.CompositionOfOrder newCompound = new Database.CompositionOfOrder();
                    newCompound.NumberOrder = number;
                    newCompound.Course = buscket.Key.NameCourse;
                    newCompound.Count = buscket.Value;

                    Connection.CompositionOfOrders.Add(newCompound);
                }
                Connection.SaveChanges();
                StackPanel.Children.Clear();
                BuyMenu.Clear();
                NavigationService.Navigate(MainMenu);
            }
        }
    }
}
