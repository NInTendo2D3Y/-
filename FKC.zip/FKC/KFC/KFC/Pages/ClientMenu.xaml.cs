﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC.Pages
{

    public partial class ClientMenu : Page
    {
       public static Pages.Buy BuyPage;

        public ClientMenu()
        {
            InitializeComponent();
            Build();
            BuyPage = new Pages.Buy();
        }
        void Build()
        {
            Database.DBEntities Connection = new Database.DBEntities();

            List<Database.Course> courseList = Connection.Courses.OrderBy(n => n.NameCourse).ToList();
            MenuClient.Children.Clear();
            List<Database.FoodSet> setList = Connection.FoodSets.OrderBy(m => m.Name).ToList();
            foreach (var Foodset in setList)
            {

                StackPanel SetList = new StackPanel();
                SetList.Orientation = Orientation.Horizontal;
                SetList.VerticalAlignment = VerticalAlignment.Center;
                SetList.Height = 200;
                SetList.Width = 800;
                SetList.Margin = new Thickness(0, 0, 0, 20);
                SetList.Background = new SolidColorBrush(Colors.PeachPuff);
                MenuClient.Children.Add(SetList);

                StackPanel CompositionName = new StackPanel();
                CompositionName.Orientation = Orientation.Vertical;
                CompositionName.HorizontalAlignment = HorizontalAlignment.Center;
                CompositionName.Margin = new Thickness(35, 20, 0, 10);
                SetList.Children.Add(CompositionName);

                TextBlock Set = new TextBlock();
                Set.Text = "Набор блюд: " + Foodset.Name;
                Set.Width = 500;
                Set.Height = 50;
                Set.TextWrapping = TextWrapping.Wrap;
                Set.FontFamily = new FontFamily("Bahnschrift Light");
                Set.FontSize = 22;
                CompositionName.Children.Add(Set);

                TextBlock Setik = new TextBlock();

                decimal price = 0;
                Setik.Text = " Состав набора включает в себя :\n";
                List<Database.CourseSet> CourseList = Foodset.CourseSets.ToList();
                foreach (var course in CourseList)
                {
                    Setik.Text += Convert.ToString(course.Course1.NameCourse);
                    if (course.Count > 1)
                    {
                        Setik.Text += " " + course.Count + " шт.";
                    }
                    Setik.Text += "\n";
                    price += course.Course1.Cost;
                }
                price = price * Convert.ToDecimal(1.1);
                Setik.Width = 500;
                Setik.Height = 100;
                Setik.TextWrapping = TextWrapping.Wrap;
                Setik.FontFamily = new FontFamily("Bahnschrift Light");
                Setik.FontSize = 18;
                CompositionName.Children.Add(Setik);

                StackPanel PriceKey = new StackPanel();
                PriceKey.Orientation = Orientation.Vertical;
                PriceKey.HorizontalAlignment = HorizontalAlignment.Center;
                PriceKey.Margin = new Thickness(0, 10, 0, 10);
                SetList.Children.Add(PriceKey);

                TextBlock Price = new TextBlock();
                Price.Text = "(っ◔◡◔)っ " + Math.Round(price, 2) + " руб.";
                Price.Width = 300;
                Price.Height = 90;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Bahnschrift Light");
                Price.FontSize = 22;
                Price.Margin = new Thickness(0, 10, 0, 0);
                SetList.Children.Add(Price);

                Button AddCourse = new Button();
                AddCourse.Width = 220;
                AddCourse.Height = 60;
                AddCourse.FontFamily = new FontFamily("Bahnschrift Light");
                AddCourse.FontSize = 22;
                AddCourse.HorizontalAlignment = HorizontalAlignment.Left;
                AddCourse.Click += Button_Click;
                AddCourse.DataContext = Foodset.Name;
                SetList.Children.Add(AddCourse);
            }
            foreach (var Course in courseList)
            {
                StackPanel coursesPanel = new StackPanel();
                coursesPanel.Orientation = Orientation.Horizontal;
                coursesPanel.VerticalAlignment = VerticalAlignment.Center;
                coursesPanel.Height = 200;
                coursesPanel.Width = 800;
                coursesPanel.Margin = new Thickness(0, 0, 0, 20);
                coursesPanel.Background = new SolidColorBrush(Colors.PapayaWhip);
                MenuClient.Children.Add(coursesPanel);

                StackPanel Calories = new StackPanel();
                Calories.Orientation = Orientation.Vertical;
                Calories.HorizontalAlignment = HorizontalAlignment.Center;
                Calories.Margin = new Thickness(35, 20, 0, 10);
                coursesPanel.Children.Add(Calories);

                TextBlock Name = new TextBlock();
                Name.Text = Course.NameCourse;
                Name.Width = 500;
                Name.Height = 120;
                Name.TextWrapping = TextWrapping.Wrap;
                Name.FontFamily = new FontFamily("Bahnschrift Light");
                Name.FontSize = 22;
                Calories.Children.Add(Name);

                TextBlock CaloriesText = new TextBlock();
                List<Database.CompositionOfTheDish> ingredient = Connection.CompositionOfTheDishes.ToList();
                double calories = 0;
                foreach (var com in ingredient)
                {
                    if (com.Measure == "шт." && com.NameCourse == Course.NameCourse)
                    {
                        calories += com.Amount * com.Ingredient.Calories;
                    }
                    else if (com.NameCourse == Course.NameCourse)
                    {
                        calories += com.Amount * com.Ingredient.Calories / 100;
                    }

                }
                CaloriesText.Text = Convert.ToString(calories) + " ккал.";
                CaloriesText.Width = 500;
                CaloriesText.Height = 100;
                CaloriesText.TextWrapping = TextWrapping.Wrap;
                CaloriesText.FontFamily = new FontFamily("Bahnschrift Light");
                CaloriesText.FontSize = 22;
                Calories.Children.Add(CaloriesText);

                StackPanel PriceKeyPanel = new StackPanel();
                PriceKeyPanel.Orientation = Orientation.Vertical;
                PriceKeyPanel.HorizontalAlignment = HorizontalAlignment.Center;
                coursesPanel.Children.Add(PriceKeyPanel);

                TextBlock Price = new TextBlock();
                Price.Text = Convert.ToString(Math.Round(Course.Cost, 2)) + " руб.";
                Price.Width = 300;
                Price.Height = 90;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Bahnschrift Light");
                Price.FontSize = 22;
                Price.Margin = new Thickness(0, 20, 0, 10);
                PriceKeyPanel.Children.Add(Price);

                Button AddCourse = new Button();
                AddCourse.Width = 220;
                AddCourse.Height = 60;
                AddCourse.FontFamily = new FontFamily("Bahnschrift Light");
                AddCourse.FontSize = 22;
                AddCourse.HorizontalAlignment = HorizontalAlignment.Left;
                AddCourse.Click += AddDish_Click;
                AddCourse.DataContext = Course.NameCourse;
                PriceKeyPanel.Children.Add(AddCourse);

            }


        }



        private void AddDish_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                string name = button.DataContext as string;
                if (name != null)
                {
                    if (Buy.BuyMenu.ContainsKey(name) == true)
                    {
                        var buscket = Buy.BuyMenu[name];
                        buscket.Count++;
                        Buy.BuyMenu[name] = buscket;
                    }
                    else
                    {
                        Buy.BuyMenu.Add(name, new Buy.BuyMenuInfo() { Count = 1, Seti4ek = false });
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            BuyPage.Build();
            NavigationService.Navigate(BuyPage);
        }
        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                string name = button.DataContext as string;
                if (name != null)
                {
                    if (Buy.BuyMenu.ContainsKey(name) == true)
                    {
                        var buscket = Buy.BuyMenu[name];
                        buscket.Count++;
                        Buy.BuyMenu[name] = buscket;
                    }
                    else
                    {
                        Buy.BuyMenu.Add(name, new Buy.BuyMenuInfo() { Count = 1, Seti4ek = true });
                    }
                }
            }
        }

    }
}